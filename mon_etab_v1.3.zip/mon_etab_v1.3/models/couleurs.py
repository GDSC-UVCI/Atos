# Constantes pour les couleurs
jaune = '\033[0;93m'
vert = '\033[0;92m'
rouge = '\033[0;91m'
cyan = '\033[0;96m'
magenta = '\033[0;35m'
reset = '\033[0m'